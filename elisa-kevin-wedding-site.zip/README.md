# Elisa & Kevin – Wedding website

Ready-to-deploy Vite + React project for Netlify.

## How to deploy on Netlify
1. Download and unzip this folder.
2. Create a new site on https://app.netlify.com/ → **Add new site** → **Import an existing project**.
3. Choose your repo or use **Deploy manually** (drag & drop the zipped `dist` after building).
4. If using a repo: Netlify will auto-detect the build:
   - Build command: `npm run build`
   - Publish directory: `dist`
5. In your terminal locally:
   ```bash
   npm install
   npm run build
   ```
   Then either push to your repo or drag & drop the `dist/` folder into Netlify (Deploys → Upload a deploy).

## Images
Place your images in `public/images/`. We already included:
- `hero.jpg` (cover)
- `photo1.jpg` … `photo6.jpg` (gallery)

You can replace them with your own files using the same names.

## Local development
```bash
npm install
npm run dev
```

Open http://localhost:5173 to preview.
