import React, { useState } from "react";

export default function WeddingSite() {
  const [lang, setLang] = useState("en");
  const languages = ["en", "es", "it", "fr"];

  return (
    <div className="min-h-screen" style={{background: 'linear-gradient(to bottom, #fff1f2, white)', color: '#262626'}}>
      {/* HEADER WITH LANGUAGE SELECTOR */}
      <header style={{position:'sticky', top:0, zIndex:30, backdropFilter:'blur(6px)', background:'rgba(255,255,255,0.8)', borderBottom:'1px solid #e5e5e5'}}>
        <div style={{maxWidth:'72rem', margin:'0 auto', padding:'0 1rem', height:'4rem', display:'flex', alignItems:'center', justifyContent:'space-between'}}>
          <div style={{fontFamily:'serif', fontSize:'1.25rem'}}>Elisa & Kevin</div>
          <nav style={{display:'flex', gap:'1rem', fontSize:'.875rem'}}>
            <a href="#gallery" style={{textDecoration:'none'}}>Gallery</a>
            <a href="#rsvp" style={{textDecoration:'none'}}>RSVP</a>
            <select
              value={lang}
              onChange={(e) => setLang(e.target.value)}
              style={{border:'1px solid #d4d4d4', borderRadius:'0.5rem', padding:'0.25rem 0.5rem', background:'#fff'}}
            >
              {languages.map((l) => (
                <option key={l} value={l}>{l.toUpperCase()}</option>
              ))}
            </select>
          </nav>
        </div>
      </header>

      {/* HERO SECTION WITH MAIN PHOTO */}
      <section style={{position:'relative', overflow:'hidden'}}>
        <img
          src="/images/hero.jpg"
          alt="Elisa & Kevin"
          style={{position:'absolute', inset:0, width:'100%', height:'100%', objectFit:'cover', opacity:0.7}}
        />
        <div style={{position:'relative', zIndex:10, textAlign:'center', padding:'8rem 1rem', backdropFilter:'blur(4px)', background:'rgba(255,255,255,0.6)'}}>
          <h1 style={{fontFamily:'serif', fontSize:'clamp(2.5rem, 6vw, 4.5rem)', letterSpacing:'-0.02em', margin:0}}>Elisa & Kevin</h1>
          <p style={{marginTop:'0.75rem', color:'#525252', fontSize:'1.125rem'}}>29 August 2026 · Sestri Levante (Liguria, Italy)</p>
          <a
            href="#rsvp"
            style={{marginTop:'1.5rem', display:'inline-block', padding:'0.75rem 1.25rem', borderRadius:'1rem', background:'#f43f5e', color:'#fff', boxShadow:'0 1px 2px rgba(0,0,0,0.1)'}}
          >
            Confirm attendance
          </a>
        </div>
      </section>

      {/* GALLERY */}
      <section id="gallery" style={{padding:'4rem 0'}}>
        <div style={{maxWidth:'72rem', margin:'0 auto', padding:'0 1rem'}}>
          <h2 style={{fontFamily:'serif', fontSize:'2rem', textAlign:'center', marginBottom:'2rem'}}>Our moments</h2>
          <div style={{display:'grid', gridTemplateColumns:'repeat(2, 1fr)', gap:'1rem'}}>
            <img src="/images/photo1.jpg" alt="Elisa & Kevin" style={{borderRadius:'0.75rem', objectFit:'cover', width:'100%', height:'100%'}} />
            <img src="/images/photo2.jpg" alt="Elisa & Kevin" style={{borderRadius:'0.75rem', objectFit:'cover', width:'100%', height:'100%'}} />
            <img src="/images/photo3.jpg" alt="Elisa & Kevin" style={{borderRadius:'0.75rem', objectFit:'cover', width:'100%', height:'100%'}} />
            <img src="/images/photo4.jpg" alt="Elisa & Kevin" style={{borderRadius:'0.75rem', objectFit:'cover', width:'100%', height:'100%'}} />
            <img src="/images/photo5.jpg" alt="Elisa & Kevin" style={{borderRadius:'0.75rem', objectFit:'cover', width:'100%', height:'100%'}} />
            <img src="/images/photo6.jpg" alt="Elisa & Kevin" style={{borderRadius:'0.75rem', objectFit:'cover', width:'100%', height:'100%'}} />
          </div>
        </div>
      </section>

      {/* RSVP SECTION */}
      <section id="rsvp" style={{padding:'4rem 0', background:'#fff1f2'}}>
        <div style={{maxWidth:'48rem', margin:'0 auto', padding:'0 1rem', textAlign:'center'}}>
          <h2 style={{fontFamily:'serif', fontSize:'2rem', marginBottom:'1.5rem'}}>Confirm attendance</h2>
          <form className="space-y-4" style={{textAlign:'left', display:'grid', gap:'1rem'}} onSubmit={(e)=>{e.preventDefault(); alert('Thank you!')}}>
            <label style={{display:'block'}}>
              <span style={{fontSize:'.875rem', color:'#404040'}}>Name *</span>
              <input type="text" required style={{width:'100%', marginTop:'0.25rem', border:'1px solid #d4d4d4', borderRadius:'0.75rem', padding:'0.5rem 0.75rem'}} />
            </label>
            <label style={{display:'block'}}>
              <span style={{fontSize:'.875rem', color:'#404040'}}>Email *</span>
              <input type="email" required style={{width:'100%', marginTop:'0.25rem', border:'1px solid #d4d4d4', borderRadius:'0.75rem', padding:'0.5rem 0.75rem'}} />
            </label>
            <label style={{display:'block'}}>
              <span style={{fontSize:'.875rem', color:'#404040'}}>Allergies or food intolerances</span>
              <textarea style={{width:'100%', marginTop:'0.25rem', border:'1px solid #d4d4d4', borderRadius:'0.75rem', padding:'0.5rem 0.75rem', height:'6rem'}} placeholder="Please let us know..." />
            </label>
            <button type="submit" style={{marginTop:'0.5rem', padding:'0.75rem 1.25rem', background:'#f43f5e', color:'#fff', borderRadius:'1rem', boxShadow:'0 1px 2px rgba(0,0,0,0.1)'}}>Send</button>
          </form>
        </div>
      </section>

      {/* FOOTER */}
      <footer style={{textAlign:'center', padding:'2.5rem 1rem', borderTop:'1px solid #e5e5e5', fontSize:'.875rem', color:'#525252'}}>
        <p>© 2026 Elisa & Kevin · Sestri Levante</p>
      </footer>
    </div>
  );
}
